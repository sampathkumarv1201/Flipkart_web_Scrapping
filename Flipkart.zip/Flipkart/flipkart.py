from selenium import webdriver
from bs4 import BeautifulSoup
from selenium.webdriver.chrome.options import Options
import requests

options = Options()
options.headless = True
driver = webdriver.Chrome(options=options) 
driver.get('https://www.flipkart.com/search?q=mobiles')

res=driver.execute_script("return document.documentElement.outerHTML;")
driver.quit()

soup= BeautifulSoup(res, "lxml")

box=soup.find_all('div', {'class':'_1UoZlX'})

products=[]
for product in box:
    prod_name=product.find('div',{'class':'_3wU53n'}).text.strip()